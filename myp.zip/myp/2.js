/**
 * โจทย์ backend ข้อที่ 2
 * คำอธิบาย : ให้สลับ index ของข้อมูลที่อยู่ใน array โดยมีเงื่อนไขคือ
 * 1. ให้สลับ index ที่ 1 กับ index ที่ 2 
 * 
 * หลังจากนั้นทำการ return array ที่สลับค่าเสร็จแล้วออกมา
 * 
 * ตัวอย่าง 
 * student = ['Bomgay', 'Ohm', 'Smart' ]
 * 
 * ผลลัพธ์
 * student = ['Bomgay', 'Smart', 'Ohm' ]
 */
student = ['Bomgay', 'Ohm', 'Smart' ]
    // function exam02(arr) {
    //     const temp = arr[2]
    //     arr[2] = arr[1]
    //     arr[1] = temp
    //     return arr;
    // }
    function exam02(arr) {
        // ใช้ array.splice() ในการสลับ index ที่ต้องการ
        // ในที่นี้ใช้ splice(index, how many items to remove, item1, item2...) ในการสลับ index ที่ 1 กับ 2 ที่มีค่าเท่ากัน
        // และใช้ push() ในการเพิ่มค่าใหม่ใน array ที่ต้องการ
        // ในที่นี้ใช้ push(arr[2], arr[1]) ในการเพิ่มค่าใหม่ใน array ที่สลับ index ที่ 2 กับ 1 ที่มีค่าเท่า�
        arr.splice(1, 2, arr[2], arr[1]);
        return arr;
    }
    // function exam02(arr) {
    //     // ใช้ destructuring assignment ในการสลับ index ที่ต้องการ
    //     [arr[1], arr[2]] = [arr[2], arr[1]];
    //     return arr;
    // }
    
    
    console.log(exam02(student));