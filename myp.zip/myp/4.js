arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
let max_min = (arr) => {
    max = Math.max(...arr)
    min = Math.min(...arr)
    return max + min;  // return max + min value as the result.  // example: 25 (max: 10, min: 1)  // you can change the output value as per your requirement.  // example: 25 (max: 10, min: 1)  // you can change the output value as per your requirement.  // example: 25 (max: 10, min: 1)
}
console.log(max_min(arr));
