function exam01(arr) {
    //  แก้ไขโค้ดตรงนี้
    //  ใช้ฟังก์ชัน forEach ใน array เพื่อทำงานกับสมาชิกของ array
    //  ถ้าสมาชิกเป็น number ให้บวกลงในตัวแปร sum
    //  ถ้าสมาชิกเป็น string แต่มีตัวเลขผสมอยู่ใน string ให้ตัดตัวอักษรออกและเปลี่ยนค่ามาเป็น int และบวกลงในตัวแปร sum
    let sum = 0;
    //  ใช้ฟังก์ชัน parseInt
    arr.forEach((item) => {
        if (typeof item === 'number') {
            sum += item;
        } else if (typeof item === 'string') {
            num = parseInt(item.replace(/\D/g, ''));
            if (num) {
                sum += num;
            }
        }
    })
    return sum;
}
array = [ '1a', 2, 's3', 4, '6fgd', 'imposter' ]
array2 = [ 'a1a', 2, 's3', 9, '6', 'asd' ]
array3 = [ 1, '2a', '3abc', 4, 'def5', 'b6' ]
console.log(array)
console.log(exam01(array));
console.log(array2)
console.log(exam01(array2));
console.log(array3)
console.log(exam01(array3));
